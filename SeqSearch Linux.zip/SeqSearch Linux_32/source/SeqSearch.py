# -*- coding: utf-8 -*-
import pygtk, gtk, gobject
from Bio import Entrez
from shutil import copyfile
import os, sys, webbrowser

def protein(self, ce, ci, parcial, va, vmi, vma):
    va = "falso"
    if parcial.get_active():
        va = "verdadeiro"
    v1 = ce.get_text()
    v2 = ci.get_text()
    v3 = va
    v4 = vmi.get_text()
    v5 = vma.get_text()
    if len(v1) == 0:
        ml = gtk.MessageDialog(None, 0, gtk.MESSAGE_WARNING,
            gtk.BUTTONS_OK, "Please enter the search terms!")
        ml.run()
        ml.destroy()
        return
    else:
        search = v1 + " " + 'AND' + " " + v2 +'[TI]'
    if v3 == "verdadeiro":
	    search = search + " " + 'NOT' + " " + 'partial'
    if len(v2) == 0:
        mr = gtk.MessageDialog(None, 0, gtk.MESSAGE_WARNING,
            gtk.BUTTONS_OK, "Please enter the name of the protein!")
        mr.run()
        mr.destroy()
        return
    if v4 and v5 != 0:
	    search = search + " " + 'AND' + " " + v4 + ':' + v5 + '[SLEN]'
    Entrez.email = "laplic@cb.ufrn.br"
    handle = Entrez.esearch(db="protein", term=str(search), retstart=0, retmax=10000)
    record = Entrez.read(handle)
    ids = record["IdList"]
    ids = ",".join(ids)
    handle = Entrez.efetch(db="protein", id=ids, rettype="fasta", retmode="text", seq_start=1)
    record = handle.read()
    fnl = None
    try:
        fnl = open('protein_seq.fasta','w+')
        fnl.write(record)
        while True:
            if os.stat('protein_seq.fasta').st_size > 0:
                break
            else:
    	        mp = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO,
                    gtk.BUTTONS_OK, "No sequences were found with the entered terms")
                mp.run()
                mp.destroy()
                fnl.close()
                return
        fim = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO,
            gtk.BUTTONS_OK, "Download completed!")
        fim.run()
        fim.destroy()
        messageWindow_prot()
    finally:
        if fnl is not None:
            fnl.close()

def nuccore(self, genome, cds, ca, co, var, vari, vmin, vmax):
    var = "falso"
    vari = "falso"
    if genome.get_active():
        var = "verdadeiro"
    elif cds.get_active():
        vari = "verdadeiro"
    val1 = ca.get_text()
    val2 = co.get_text()
    val3 = var
    val4 = vari
    val5 = vmin.get_text()
    val6 = vmax.get_text()
    if len(val1) == 0:
        md = gtk.MessageDialog(None, 0, gtk.MESSAGE_WARNING,
            gtk.BUTTONS_OK, "Please enter the search terms!")
        md.run()
        md.destroy()
        return
    else:
        search = ""
    if len(val2) == 0 and val3 == "verdadeiro":
        search = val1 + " " + 'AND' + " " + 'complete genome[TI]'
    elif len(val2) != 0 and val4 == "verdadeiro":
        search = val1 + " " + 'AND' + " " + val2 + '[TI]' + " " + 'AND' + " " + 'complete cds[TI]'
    elif len(val2) == 0 and val4 == "verdadeiro":
        mm = gtk.MessageDialog(None, 0, gtk.MESSAGE_WARNING,
            gtk.BUTTONS_OK, "Please enter the name of the gene or ORF!")
        mm.run()
        mm.destroy()
        return
    elif val3 or val4 == "falso":
        me = gtk.MessageDialog(None, 0, gtk.MESSAGE_WARNING,
            gtk.BUTTONS_OK, "Please select complete genome or complete cds!")
        me.run()
        me.destroy()
	return
    elif len(val2) == 0 and val3 == "verdadeiro" and val5 !=0 and val6 != 0:
        search = val1 + " " + 'AND' + " " + 'complete genome[TI]' + " " + val5 + ':' + val6 + '[SLEN]'
    elif len(val2) != 0 and val4 == "verdadeiro" and val5 !=0 and val6 != 0:
        search = val1 + " " + 'AND' + " " + val2 + '[TI]' + " " + 'AND' + " " + 'complete cds[TI]' + " " + val5 + ':' + val6 + '[SLEN]'
    Entrez.email = "laplic@cb.ufrn.br"
    handle = Entrez.esearch(db="nucleotide", term=str(search), retstart=0, retmax=10000)
    record = Entrez.read(handle)
    ids = record["IdList"]
    ids = ",".join(ids)
    handle = Entrez.efetch(db="nucleotide", id=ids, rettype="fasta", retmode="text", seq_start=1)
    record = handle.read()
    final = None
    try:
        final = open('nucleotide_seq.fasta','w+')
        final.write(record)
        while True:
            if os.stat('nucleotide_seq.fasta').st_size > 0:
                break
            else:
    	        mf = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO,
                    gtk.BUTTONS_OK, "No sequences were found with the entered terms")
                mf.run()
                mf.destroy()
                final.close()
                return
        fin = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO,
            gtk.BUTTONS_OK, "Download completed!")
        fin.run()
        fin.destroy()
        messageWindow_nuc()
    finally:
        if final is not None:
            final.close()

class Buscador(gtk.Window):
    def __init__(self):
        gtk.Window.__init__(self)
        self.set_title("SeqSearch")
        self.set_resizable(False)
        self.set_border_width(5)
        self.modify_bg(gtk.STATE_NORMAL, None)
        self.set_position(gtk.WIN_POS_CENTER)
        self.notebook = gtk.Notebook()
        self.add(self.notebook)

#FRAME NUCLEOTIDE
        self.page1 = gtk.VBox(homogeneous=False, spacing=0)
        self.page1.set_border_width(5)
        self.notebook.append_page(self.page1, gtk.Label('Nucleotide'))

        image1 = gtk.Image()
        image1.set_from_file("introdna.png")
        image1.show()
        self.page1.pack_start(image1, False, False, 10)

        text1 = gtk.Label("Enter the name of the organism or specie:")
        self.page1.pack_start(text1, False, False, 10)

        ca = gtk.Entry()
        ca.set_editable(True)
        self.page1.pack_start(ca, False, False, 0)

        text2 = gtk.Label("Enter the name of the gene or ORF:")
        self.page1.pack_start(text2, False, False, 10)

        co = gtk.Entry()
        co.set_editable(True)
        self.page1.pack_start(co, False, False, 0)

        advic1 = gtk.Label()
        advic1.set_markup("<small><i>This field can be left blank</i></small>")
        self.page1.pack_start(advic1, False, False, 0)

    	var = "falso"
    	genome = gtk.CheckButton(label="Complete genome")
    	genome.set_active(False)
        self.page1.pack_start(genome, False, False, 10)

    	vari = "falso"
    	cds = gtk.CheckButton(label="Complete cds")
        cds.set_active(False)
    	self.page1.pack_start(cds, False, False, 10)

        advic2 = gtk.Label()
        advic2.set_markup("<small><i>Select complete cds when searching for a specific gene or ORF</i></small>")
        self.page1.pack_start(advic2, False, False, 0)

        text3 = gtk.Label("OPTIONAL: Do you want to set a size range for the sequences?\nThis may help you filter the results")
        self.page1.pack_start(text3, False, False, 20)

        text4 = gtk.Label("Minimum size")
        text5 = gtk.Label("Maximum size")
        vmin = gtk.Entry()
        vmin.show()
        vmax = gtk.Entry()
        vmax.show()
        self.page1.pack_start(text4, False, False, 0)
        self.page1.pack_start(vmin, False, False, 0)
        self.page1.pack_start(text5, False, False, 0)
        self.page1.pack_start(vmax, False, False, 0)

        button = gtk.Button(label="DOWNLOAD")
        button.connect("released", nuccore, genome, cds, ca, co, var, vari, vmin, vmax)
        self.page1.pack_start(button, False, False, 10)

#FRAME PROTEIN
        self.page2 = gtk.VBox(homogeneous=False, spacing=0)
        self.page2.set_border_width(5)
        self.notebook.append_page(self.page2, gtk.Label('Protein'))

        image2 = gtk.Image()
        image2.set_from_file("introprot.png")
        image2.show()
        self.page2.pack_start(image2, False, False, 10)

        text6 = gtk.Label("Enter the name of the organism or specie:")
        self.page2.pack_start(text6, False, False, 10)

        ce = gtk.Entry()
        ce.set_editable(True)
        self.page2.pack_start(ce, False, False, 0)

        text7 = gtk.Label("Enter the name of the protein:")
        self.page2.pack_start(text7, False, False, 10)

        ci = gtk.Entry()
        ci.set_editable(True)
        self.page2.pack_start(ci, False, False, 0)

        advic3 = gtk.Label()
        advic3.set_markup("<small><i>Required field</i></small>")
        self.page2.pack_start(advic3, False, False, 0)

        va = "falso"
    	parcial = gtk.CheckButton(label="Remove partial sequences")
    	parcial.set_active(False)
        self.page2.pack_start(parcial, False, False, 10)

        advic4 = gtk.Label()
        advic4.set_markup("<small><i>Select this option if you are looking for complete sequences only</i></small>")
        self.page2.pack_start(advic4, False, False, 0)

        text8 = gtk.Label("OPTIONAL: Do you want to set a size range for the sequences?\nThis may help you filter the results")
        self.page2.pack_start(text8, False, False, 20)

        text9 = gtk.Label("Minimum size")
        text10 = gtk.Label("Maximum size")
        vmi = gtk.Entry()
        vmi.show()
        vma = gtk.Entry()
        vma.show()
        self.page2.pack_start(text9, False, False, 0)
        self.page2.pack_start(vmi, False, False, 0)
        self.page2.pack_start(text10, False, False, 0)
        self.page2.pack_start(vma, False, False, 0)

        buttn = gtk.Button(label="DOWNLOAD")
        buttn.connect("released", protein, ce, ci, parcial, va, vmi, vma)
        self.page2.pack_start(buttn, False, False, 40)

#FRAME ABOUT
        self.page3 = gtk.VBox(homogeneous=False, spacing=0)
        self.page3.set_border_width(5)
        self.notebook.append_page(self.page3, gtk.Label('About'))

        abt = gtk.Label("Version 1.0\nby Gustavo Cavalcante\n\nApplied Molecular Biology Lab (LAPLIC)\nFederal University of Rio Grande do Norte (UFRN)\n\nhttp://www.laplic.com.br\n\nContact: gugahenriqe@gmail.com")
        abt.set_alignment(xalign=0.5, yalign=0.5)
        self.page3.pack_start(abt, False, False, 10)

def messageWindow_nuc():
    jan = gtk.Window(gtk.WINDOW_TOPLEVEL)
    jan.set_title("Alignment")
    jan.set_resizable(False)
    vbox = gtk.VBox(homogeneous=False, spacing=0)
    vbox.set_border_width(15)
    jan.add(vbox)
    jan.set_position(gtk.WIN_POS_CENTER)
    lb = gtk.Label("ALIGN SEQUENCES?\n\n\nThis step requires processing from your computer and may be slow depending on the number of sequences")
    lb.set_alignment(xalign=0.5, yalign=0.5)
    vbox.pack_start(lb, False, False, 10)
    bt_musc = gtk.Button(label="MUSCLE")
    bt_musc.connect("released", musc_nuc)
    bt_mafft = gtk.Button(label="MAFFT")
    bt_mafft.connect("released", maf_nuc)
    bt_clustal = gtk.Button(label="Clustal Omega")
    bt_clustal.connect("released", clu_nuc)
    nada = gtk.Button(label="Do not align")
    nada.connect("released", do_nothing)
    vbox.pack_start(bt_musc, False, False, 5)
    vbox.pack_start(bt_mafft, False, False, 5)
    vbox.pack_start(bt_clustal, False, False, 5)
    vbox.pack_start(nada, False, False, 5)
    jan.show_all()

def messageWindow_prot():
    jn = gtk.Window(gtk.WINDOW_TOPLEVEL)
    jn.set_title("Alignment")
    jn.set_resizable(False)
    jn.set_position(gtk.WIN_POS_CENTER)
    vboxe = gtk.VBox(homogeneous=False, spacing=0)
    vboxe.set_border_width(15)
    jn.add(vboxe)
    lbe = gtk.Label("ALIGN SEQUENCES?\n\n\nThis step requires processing from your computer and may be slow depending on the number of sequences")
    lbe.set_alignment(xalign=0.5, yalign=0.5)
    vboxe.pack_start(lbe, False, False, 10)
    btn_musc = gtk.Button(label="MUSCLE")
    btn_musc.connect("released", musc_prot)
    btn_mafft = gtk.Button(label="MAFFT")
    btn_mafft.connect("released", maf_prot)
    btn_clustal = gtk.Button(label="Clustal Omega")
    btn_clustal.connect("released", clu_prot)
    nda = gtk.Button(label="Do not align")
    nda.connect("released", do_noth)
    vboxe.pack_start(btn_musc, False, False, 5)
    vboxe.pack_start(btn_mafft, False, False, 5)
    vboxe.pack_start(btn_clustal, False, False, 5)
    vboxe.pack_start(nda, False, False, 5)
    jn.show_all()

def musc_nuc(bt_musc):
    musc = os.system('./muscle/muscle3.8.31_i86linux32 -in nucleotide_seq.fasta -out nucleotide_aligned_muscle.fasta')
    copyfile('nucleotide_aligned_muscle.fasta', 'Fasta/nucleotide_aligned_muscle.fasta')
    webbrowser.open('Fasta/nucleotide_aligned_muscle.fasta')

def maf_nuc(bt_mafft):
    maf = os.system('./mafft-linux32/mafft.bat --auto nucleotide_seq.fasta > nucleotide_aligned_mafft.fasta')
    copyfile('nucleotide_aligned_mafft.fasta', 'Fasta/nucleotide_aligned_mafft.fasta')
    webbrowser.open('Fasta/nucleotide_aligned_mafft.fasta')

def clu_nuc(bt_clustal):
    clu = os.system('./clustalo/clustalo-1.2.4-Ubuntu-32-bit -i nucleotide_seq.fasta -o nucleotide_aligned_clustalo.fasta --outfmt=fasta --force')
    copyfile('nucleotide_aligned_clustalo.fasta', 'Fasta/nucleotide_aligned_clustalo.fasta')
    webbrowser.open('Fasta/nucleotide_aligned_clustalo.fasta')

def do_nothing(nada):
    copyfile('nucleotide_seq.fasta', 'Fasta/nucleotide_seq.fasta')
    webbrowser.open('Fasta/nucleotide_seq.fasta')

def musc_prot(btn_musc):
    muscl = os.system('./muscle/muscle3.8.31_i86linux32 -in protein_seq.fasta -out protein_aligned_muscle.fasta')
    copyfile('protein_aligned_muscle.fasta', 'Fasta/protein_aligned_muscle.fasta')
    webbrowser.open('Fasta/protein_aligned_muscle.fasta')

def maf_prot(btn_mafft):
    maft = os.system('./mafft-linux32/mafft.bat --auto protein_seq.fasta > protein_aligned_mafft.fasta')
    copyfile('protein_aligned_mafft.fasta', 'Fasta/protein_aligned_mafft.fasta')
    webbrowser.open('Fasta/protein_aligned_mafft.fasta')

def clu_prot(btn_clustal):
    clus = os.system('./clustalo/clustalo-1.2.4-Ubuntu-32-bit -i protein_seq.fasta -o protein_aligned_clustalo.fasta --outfmt=fasta --force')
    copyfile('protein_aligned_clustalo.fasta', 'Fasta/protein_aligned_clustalo.fasta')
    webbrowser.open('Fasta/protein_aligned_clustalo.fasta')

def do_noth(nda):
    copyfile('protein_seq.fasta', 'Fasta/protein_seq.fasta')
    webbrowser.open('Fasta/protein_seq.fasta')

win = Buscador()
win.connect("delete-event", gtk.main_quit)
win.show_all()
gtk.main()
